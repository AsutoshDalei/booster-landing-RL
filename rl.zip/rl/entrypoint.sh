#!/bin/bash
set -e

echo "========================================"
echo "    Starting Falcon RL Environment      "
echo "========================================"

# 1. Start the Node.js Simulation Server in the background
echo "[1/2] Launching Physics Server (server.js)..."
nohup node server.js > simulator.log 2>&1 &
SERVER_PID=$!
echo "      Server started with PID: $SERVER_PID"

# 2. Wait for server to initialize
echo "      Waiting 3 seconds for server to bind..."
sleep 3

# 3. Start the Python Training Script
echo "[2/2] Starting PyTorch Training (train_falcon_rl.py)..."
python train_falcon_rl.py

echo "========================================"
echo "       Training Session Complete        "
echo "========================================"
